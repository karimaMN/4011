const Blog = require('../models/Blogs')

const PostBlogs = async (req,res,next) => {
    const blogs = await Blog.find()
    res.send(blogs)
}

module.exports = PostBlogs