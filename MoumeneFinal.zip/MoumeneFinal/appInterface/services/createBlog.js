const Blog = require('../models/Blogs')

const CreateBlog = async (req, res, next) => {
    try{
        const blog = new Blog({
            title: req.body.title,
            content: req.body.content,
        })
        
        const result = await blog.save()
        res.send(result)
    } catch(e){
        res.status(400).send('Somthing Wrong!')
    }
}
module.exports = CreateBlog