const Blog = require('../models/Blogs')


    const UpdateBlog = async (req, res, next) =>{
        try{
            const id = req.query.id
            const newTitle = req.body.title
            const newContent = req.body.content
    
        const newBlog = await Blog.findByIdAndUpdate(id,{
            title: newTitle,
            content: newContent
        })
        res.send(newBlog)
    
    } catch(e){
    res.status(400).send('Somthing Wrong!')
}
}

module.exports = UpdateBlog