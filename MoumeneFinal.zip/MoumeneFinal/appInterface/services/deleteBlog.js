const Blog = require('../models/Blogs')


    const DeleteBlog = async (req, res, next) => {
        try{
        const id = req.query.id
        await Blog.findByIdAndDelete(id)
        res.send('deleted')
} catch(e){
    res.status(400).send('Somthing Wrong!')
} 
}

module.exports = DeleteBlog
