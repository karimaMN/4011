
import React, {useState, useEffect} from 'react'
import Paper from '@material-ui/core/Paper'
import superagent from 'superagent'
import Button from '@material-ui/core/Button'
import TextField from '@material-ui/core/TextField'
import Modal from '@material-ui/core/Modal'
require('./Main.css')

const Main = () => {
    const[ blogs, setBlogs ] = useState([])
    const[ newcontent, setNewcontent ] = useState('')
    const[ newtitle, setNewtitle ] = useState('')
    const [ blogId, setBlogId ] = useState('')
    const [open, setOpen] = React.useState(false);

    const handleOpen = (id) => {
        setOpen(true)
        setBlogId(id)
    }
    
    const handleClose = () => {
    setOpen(false);
  }
  
  const retrieveBlogs = async () => {
        const { body } = await superagent.get('http://localhost:3001/blogs')
        setBlogs(body)  
    }
    
  const deleteBlog = async id => {
        await superagent.delete(`http://localhost:3001/delete?id=${id}`)
        retrieveBlogs()
    }

  const createBlog = async (sometitle,somecontent)=> {
        await superagent.post(`http://localhost:3001/create`).send({ title: sometitle, content: somecontent })
        retrieveBlogs()
    }
    
  const updateBlog = async (id,sometitle,somecontent)=> {
        await superagent.post(`http://localhost:3001/update?id=${id}`).send({ title: sometitle, content: somecontent })
        retrieveBlogs()
    }

    useEffect(() => {
        retrieveBlogs()
    },[])

    return (
       <> 
        <div>
            {blogs.map(blog =>{
                return (
                    <Paper id='pap' key={blog._id} style={{width: '200px', padding: '20px'}}>
                        <h1>{blog.title}</h1>
                        <br />
                        {blog.content}
                        <br />
                        <Button id='bt' variant='contained' color="primary" onClick={() => deleteBlog(blog._id)}> 
                           Delete
                        </Button>
                        <Button variant='contained' color="primary" onClick={() => handleOpen(blog._id)}>
                           Update
                        </Button>
                        <Modal open={open}
                            id='modal'>
                           <div>
                               <h3>Edit Blog</h3>
                               <TextField label="New title" className='textf' value={newtitle} onChange={event =>setNewtitle(event.target.value)}/><br />
                               <TextField label="New Content" value={newcontent} onChange={event =>setNewcontent(event.target.value)}/> <br />
                               <Button id='savebt' variant='contained' color="primary" onClick={() => updateBlog(blogId,newtitle,newcontent)}> 
                                Save
                               </Button>
                               <Button  variant='contained' color="primary" onClick={() => handleClose()}>
                                Finish
                               </Button>
                            </div>
                        </Modal>
                    </Paper>
                )
            })}
        </div>
  
        <div id='new'>
            <h3 style = {{color: 'darkslateblue'}}>Create new Blog</h3>
            <TextField label="Title" onChange={event =>setNewtitle(event.target.value)} /><br />
            <TextField label="Content"  onChange={event =>setNewcontent(event.target.value)}/> <br />
            <Button  id='bt' variant='contained' color="primary" onClick={() => createBlog(newtitle,newcontent)}> 
             Create
            </Button>
        </div>
     </>
    )
}

export default Main