import React from 'react'
import ReactDOM from 'react-dom'
import Main from './containers/Main'

const AppContainer = () => {
    return (
        <div>
            <Main />
        </div>
    )
}

ReactDOM.render(<AppContainer />,document.querySelector('#root'))